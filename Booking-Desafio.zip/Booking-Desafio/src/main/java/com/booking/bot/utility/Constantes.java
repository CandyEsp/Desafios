package com.booking.bot.utility;

public class Constantes {

    public static String initialPrice ="";
    public static String finalPrice ="";
}
