package com.frm.bot.utility;

public class Utility {
}
