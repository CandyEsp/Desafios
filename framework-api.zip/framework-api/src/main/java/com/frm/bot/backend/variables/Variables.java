package com.frm.bot.backend.variables;

public class Variables {

    public static String url = "";
}
